<template>
  <div><h2>Home Page</h2></div>
</template>
