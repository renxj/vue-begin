<template>
  <div>
    <h1>Vite + Vue 3 + Router + Pinia + SSR ✅</h1>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
    <router-view />
  </div>
</template>
