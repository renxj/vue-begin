<template>
  <div>
    <h1>📘 About Page</h1>
    <router-link to="/">← Back Home</router-link>
  </div>
</template>